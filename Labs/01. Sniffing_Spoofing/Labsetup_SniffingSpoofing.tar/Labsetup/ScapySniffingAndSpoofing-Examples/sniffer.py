#!/usr/bin/python3
from scapy.all import *

def print_pkt(pkt):
	pkt.show()

pkt = sniff(iface='br-3afd68e68573', filter='icmp', prn=print_pkt)
