# SEED Labs Sniffing and Spoofing Lab
This repo contains the source code for the Sniffing and Spoofing SEED Labs lab report that I made a post about.
