#!/usr/bin/python3

from scapy.all import *

a = IP()

a.show()
